/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.xyneex.sales;

/**
 *
 * @author techzone
 */
public class Main 
{
    public static void main(String[] agrs)
    {
        MainFram mainframe=new MainFram();
        mainframe.setVisible(true);
       // UserProfile up=new UserProfile();
        //up.setVisible(true);
    }
    
}
