/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.xyneex.sales.util;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author techzone
 */
public final class WindowsSetter {
    public static void centralizeWindow(Window window)
    {
        Dimension dim= Toolkit.getDefaultToolkit().getScreenSize();
    int w=window.getSize().width;
    int h=window.getSize().height;
    int x=(dim.width-w)/2;
    int y=(dim.height-h)/2;
    window.setLocation(x, y);
    }
    
    public static void setNimbusLookandFeel(Window parentComponent)
    {
      try
      {
          UIManager.setLookAndFeel("com sun java swing plaf numbus NimbusLookandFeel");
      }
      catch(ClassNotFoundException | InstantiationException | IllegalAccessException| UnsupportedLookAndFeelException xcp)
      {
          JOptionPane.showMessageDialog(parentComponent, xcp.getMessage(), "Error!",JOptionPane.ERROR_MESSAGE);
xcp.printStackTrace(System.err);
      } 
              
    }
    
      public static void setWindowsLookAndFeel(Window parentComponent)
    {
      try
      {
          UIManager.setLookAndFeel("com sun java swing plaf windows WindowsLookAndFeel");
      }
      catch(ClassNotFoundException | InstantiationException | IllegalAccessException| UnsupportedLookAndFeelException xcp)
      {
          JOptionPane.showMessageDialog(parentComponent, xcp.getMessage(), "Error!",JOptionPane.ERROR_MESSAGE);
xcp.printStackTrace(System.err);
      } 
              
    }
}
